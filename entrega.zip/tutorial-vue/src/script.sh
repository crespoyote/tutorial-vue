cd ..
npm run build