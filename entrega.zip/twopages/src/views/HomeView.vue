<template>
  <main>
    <h1>Home Page</h1>
  </main>
</template>
