<template>
  <!-- cambia XXX por ONE or TWO -->
  <h1>Hi! I am page ONE!</h1>
</template>

<script>
export default {}
</script>
