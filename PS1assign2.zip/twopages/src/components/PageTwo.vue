<template>
    <!-- cambia XXX por ONE or TWO -->
    <h1>Hi! I am page TWO!</h1>
  </template>
  
  <script>
  export default {}
  </script>
  